library(shiny)
library(ggplot2)
library(dplyr)
library(shinythemes)
library(rsconnect)


car <- read.csv("car.csv", stringsAsFactors = FALSE)

ui <- navbarPage (theme = "Car Information",
                 title = "Domestic and International Brands of Automobiles and their Properties",
                 
                 tabPanel(tags$h1('Description'),
                          tags$h2(tags$strong(("Which model or brand of car do you perceive as the most cost and energy efficient?"))),
                          tags$img(width = 1500, height = 600, src= 'https://i.pinimg.com/originals/54/fd/04/54fd0407b5f2d4b96b4a1d631ca51e61.jpg'),
                          tags$h3('1. How much are you satisfied with your current car and how much information do you know about your car?'),
                          tags$h3('2. My personal car is Nissan Sentra 2013. I have all the time been curious over my car\'s mpg and horse power'),
                          tags$h3('3. Which property of car are you curious the most?')),
                 tabPanel(tags$h1('Visualization'),
                          tags$h1(tags$strong(("Domestic and International Carbrand and Properties"))),
                          tags$h3("Taeyoung Shin"),
  sidebarLayout(
    sidebarPanel(
      sliderInput("HorsePowerInput","HP", 60,150, c(70,120)),
      sliderInput("PriceInput","Price", 5800,25000, c(10000, 20000)),
      checkboxGroupInput("TypeInput", "Type", choices = c("Small", "Sporty", "Compact", "Medium", "Large", "Van"),
                         selected = "Medium"),
      selectInput("CountryInput", "Country", choices = car$Country, selected = 0),
      numericInput("ReliabilityInput", "Reliability",3, 1,5),
      submitButton()
    ),
    
    mainPanel(
      plotOutput("coolplot"),
      br(), br(),
      uiOutput("BrandOutput")
    )
  )
)

)

server <- function(input, output) {
  output$coolplot <- renderPlot({
    filtered <-
      car %>%
      filter(Price >= input$PriceInput[1],
             Price <= input$PriceInput[2],
             HP >= input$HorsePowerInput[1],
             HP <= input$HorsePowerInput[2],
             Type == input$TypeInput,
        
           
      )
    ggplot(filtered, aes(Weight)) + geom_histogram()
  })
  
  
  output$BrandOutput <- renderUI({
    selectInput("BrandInput", "Brand", car$Brand, selected = "Honda Civic 4")
  })
  
}
shinyApp(ui = ui, server = server)

